/*****************************************************************************
 *									     *
 * Copyright 2004 Greg Bryan						     *
 * Copyright 2004 Laboratory for Computational Astrophysics		     *
 * Copyright 2004 Board of Trustees of the University of Illinois	     *
 * Copyright 2004 Regents of the University of California		     *
 *									     *
 * This software is released under the terms of the "Enzo Public License"    *
 * in the accompanying LICENSE file.					     *
 *									     *
 *****************************************************************************/
/***********************************************************************
/
/  GRID CLASS (CORRECT SOLUTION GIVEN ORIGINAL AND REFINED FLUXES)
/
/  written by: Greg Bryan
/  date:       November, 1994
/  modified1:  Robert Harkness
/  date:       January, 2003
/	       Include extra fields beyond Metallicity!
/  modified2:  David Collins & Rick Wagner 
/  date:       May, 2005
/	       Include flux correction for outside grids.
/              Re-instated CorrectBoundaryFlux code.
/
/  PURPOSE:    Ensures conservation of stuff.
/
/  RETURNS: SUCCESS or FAIL
/
************************************************************************/

// Given both the original and refined fluxes for a subgrid in the current
//   grid, correct the solution in the cells just outside the solution to
//   reflect the new fluxes (which are determined from the solution of
//   the subgrid).
//   Note that if the subgrid is on the boundary of the current grid, we
//     do not correct the values but instead replace the boundary fluxes
//     for the current time step (BoundaryFluxesThisTimeStep).
//   Also note that subgrids sharing a face with This Grid, but not proper subgrids,
//   also need to be taken into account.

#include <stdio.h>
#include "macros_and_parameters.h"
#include "typedefs.h"
#include "global_data.h"
#include "Fluxes.h"
#include "GridList.h"
#include "ExternalBoundary.h"
#include "Grid.h"

/* function prototypes */

int FindField(int f, int farray[], int n);
int CosmologyComputeExpansionFactor(FLOAT time, FLOAT *a, FLOAT *dadt);

int grid::CorrectForRefinedFluxes(fluxes *InitialFluxes, 
				  fluxes *RefinedFluxes,
				  fluxes *BoundaryFluxesThisTimeStep
#ifdef JB_OPT_FLUXES_FIX
				  , int SUBlingGrid,
				  TopGridData *MetaData
#endif				  
				  )
{

  // Return if this doesn't concern us. 
  
  if (ProcessorNumber != MyProcessorNumber)
    return SUCCESS;

  // declarations 
  
  int i1, i2, i, j, k, dim, field, ffield, index;
  int FieldIndex, FluxIndex, GridFluxIndex, Offset, RefinedFluxIndex;
  int End[MAX_DIMENSION], Start[MAX_DIMENSION];
  
  //Dimensions of Initial and Refined fluxes.  ("Dim" should be "InitialDim")
  int Dim[MAX_DIMENSION],RefinedDim[MAX_DIMENSION] = {0,0,0};

  //Dimension and Start Index for the ParentGrid (this grid) boundary flux.
  int GridFluxDim[MAX_DIMENSION], GridFluxStartIndex[MAX_DIMENSION];  

  // Used for calculating position in the RefinedFlux and InitialFlux data structure.
  int RefinedOffset[MAX_DIMENSION] ={0,0,0}, InitialOffset[MAX_DIMENSION] = {0,0,0};

  //Internal flags: Correct the BarryonField 
  int CorrectLeftBaryonField, CorrectRightBaryonField;
  //For correction of the Parent Grid (this grid) boundary flux.
  int CorrectLeftBoundaryFlux, CorrectRightBoundaryFlux;

  
  long_int GlobalDim;

  /* If there are no fields, don't do anything. */

  if (NumberOfBaryonFields > 0) {

    /* Find fields: density, total energy, velocity1-3. */
    
    int DensNum, GENum, Vel1Num, Vel2Num, Vel3Num, TENum;
    if (this->IdentifyPhysicalQuantities(DensNum, GENum, Vel1Num, Vel2Num, 
					 Vel3Num, TENum) == FAIL) {
      fprintf(stderr, "Error in grid->IdentifyPhysicalQuantities.\n");
      return FAIL;
    }
    
    /* If using comoving coordinates, compute a(t) because we'll need it
       to multiply against the CellWidth. */
    
    FLOAT a = 1, dadt;
    if (ComovingCoordinates)
      if (CosmologyComputeExpansionFactor(Time, &a, &dadt) == FAIL) {
	fprintf(stderr, "Error in CosmologyComputeExpansionFactors.\n");
	return FAIL;
      }
    
  
    /* Main loop over all faces. */
    
    for (dim = 0; dim < GridRank; dim++) {
      if (GridDimension[dim] > 1) {
	
	/* Check that the dims of InitialFluxes & RefinedFluxes are the same */

	/* don't do this for SUBlings */
	if( SUBlingGrid == FALSE ){
	  for (j = 0; j < GridRank; j++)
	    if ((InitialFluxes->LeftFluxStartGlobalIndex[dim][j] !=
		 RefinedFluxes->LeftFluxStartGlobalIndex[dim][j])  ||
		(InitialFluxes->LeftFluxEndGlobalIndex[dim][j] !=
		 RefinedFluxes->LeftFluxEndGlobalIndex[dim][j])) {
	      fprintf(stderr,"InitialFluxes & RefinedFluxes are different.\n");
	      return FAIL;
	    }
	}

	//by default, we want to correct the flux.
	CorrectLeftBaryonField = CorrectRightBaryonField = TRUE;
	if( SUBlingGrid == TRUE ){
	  
	  /* calculate Global dimensions on this level */
	  GlobalDim = 	nlongint(( DomainRightEdge[dim] - DomainLeftEdge[dim])
				 / CellWidth[dim][0]);
	  
	  /* get the dims of the refined fluxes to calculate 
	     array indices */
	  
	  for (i = 0; i < MAX_DIMENSION; i++){
	    RefinedDim[i] = RefinedFluxes->LeftFluxEndGlobalIndex[dim][i] - 
	      RefinedFluxes->LeftFluxStartGlobalIndex[dim][i] + 1;
	  }
	  
	  /* check if SUBling left or right edge lies on 
	     Domain boundary, and if so, modulo the indices,
	     otherwise, bump the indices to match the initial flux's.
	  */
	  
	  if( RefinedFluxes->LeftFluxStartGlobalIndex[dim][dim] == 0 &&
	      MetaData->LeftFaceBoundaryCondition[dim] == periodic ){
	    RefinedFluxes->LeftFluxStartGlobalIndex[dim][dim] = GlobalDim - 1;
	    RefinedFluxes->LeftFluxEndGlobalIndex[dim][dim] = GlobalDim - 1;
	  }else{
	    RefinedFluxes->LeftFluxStartGlobalIndex[dim][dim]--;
	    RefinedFluxes->LeftFluxEndGlobalIndex[dim][dim]--;
	  }
	  
	  
	  if( RefinedFluxes->RightFluxStartGlobalIndex[dim][dim] == GlobalDim - 1 &&
	      MetaData->RightFaceBoundaryCondition[dim] == periodic){
	    RefinedFluxes->RightFluxStartGlobalIndex[dim][dim] = 0;
	    RefinedFluxes->RightFluxEndGlobalIndex[dim][dim] = 0;
	  }else{
	    RefinedFluxes->RightFluxStartGlobalIndex[dim][dim]++;
	    RefinedFluxes->RightFluxEndGlobalIndex[dim][dim]++;
	  }
	  
	  /* check to see if we're doing this dimension at all.
	     only the dimension of contact needs to be checked,
	     since SUBling grids can only have contact along a
	     single axis. any corrections to this statement
	     earns a beer */
	  
	  
	  //note these are integers, so comparing them directly is ok.
	  //Also note that here we don't do the complete check for SUBling-ness. 
	  //More logic is necessary for any two arbitrary grids, but it's been done
	  //already in populating the SUBling list.  Here, all we need
	  //to do is determine which face needs the correction, as we already know one exists.
	  
	  if( InitialFluxes->RightFluxStartGlobalIndex[dim][dim] ==
	      RefinedFluxes->LeftFluxStartGlobalIndex[dim][dim] ){
	    CorrectRightBaryonField = TRUE;
	  }else{
	    CorrectRightBaryonField = FALSE;
	  }
	  
	  if( InitialFluxes->LeftFluxStartGlobalIndex[dim][dim]==
	      RefinedFluxes->RightFluxStartGlobalIndex[dim][dim] ){
	    CorrectLeftBaryonField = TRUE;
	  }else{
	    CorrectLeftBaryonField = FALSE;
	  }
	  
	  for (i = 0; i < MAX_DIMENSION; i++) {
	    /* calculate the offset, so the index of the refined fluxes can
	       be determined from the grid's index */
	    RefinedOffset[i] = max(InitialFluxes->LeftFluxStartGlobalIndex[dim][i]-
				   RefinedFluxes->LeftFluxStartGlobalIndex[dim][i],0);
	  }

	  RefinedFluxes->LeftFluxStartGlobalIndex[dim][dim]=0;
	  RefinedOffset[dim]=0;

	}//Subling == TRUE	

	if( CorrectLeftBaryonField || CorrectRightBaryonField){
	  
	  /* Compute Start and end indicies of flux region (with respect to
	     the current grid's flux region). */
	  
	  for (i = 0; i < MAX_DIMENSION; i++) {
	    Start[i] = 0;
	    End[i] = 0;
	  }
	  
	  /* start index = subgrid flux left edge global index -
	     grid far left edge global index
	     end index = subgrid flux right edge -
	     grid far left edge global index. */
	  
	  /* modified to account for different dimensions to the 
	     initial and refined fluxes */
	  
	  for (i = 0; i < GridRank; i++) {
	    Start[i] = max(InitialFluxes->LeftFluxStartGlobalIndex[dim][i],
			   RefinedFluxes->LeftFluxStartGlobalIndex[dim][i]) -
	      nlongint((CellLeftEdge[i][0] - DomainLeftEdge[i])/
		       CellWidth[i][0]);
	    End[i] = min(InitialFluxes->LeftFluxEndGlobalIndex[dim][i],
			 RefinedFluxes->LeftFluxEndGlobalIndex[dim][i]) -
	      nlongint((CellLeftEdge[i][0] - DomainLeftEdge[i])/
		       CellWidth[i][0]);
	    
	    
	    if (Start[i] < 0 || End[i] > GridDimension[i]) {
	      fprintf(stderr, "Start/End[%d] = %d/%d\n", 
		      dim, Start[i], End[i]);
	      fprintf(stderr, "%"GOUTSYM" %"GOUTSYM" %lld\n",
		      CellLeftEdge[i][0], CellWidth[i][0], 
		      InitialFluxes->LeftFluxStartGlobalIndex[dim][i]);
	      return FAIL;
	    }
	  }
	  
	  /* Correct vector to point at cells just outside the left face.
	     Start[dim] and End[dim] should be the same because the
	     layer to be corrected is but one cell thick. */
	  
	  Start[dim] = max(Start[dim] - 1, 0);
	  End[dim]   = Start[dim];

	  /* Compute Dimensions of InitialFluxes */
	  
	  for (i = 0; i < MAX_DIMENSION; i++)
	    Dim[i] = End[i] - Start[i] + 1;
	  
	  /* Compute Offset (in baryon field) for right side of face.
	     The +2 is there because we want to correct the cells just the 
	     right face.*/
	  
	  Offset = InitialFluxes->RightFluxStartGlobalIndex[dim][dim] -
	    InitialFluxes->LeftFluxStartGlobalIndex[dim][dim] + 2;
	  Offset = min(Offset, GridDimension[dim]-1);  // this isn't needed (?) 


	  //For SUBling grids, alter Offset, Start, and End to reflect that we're 
	  //adjusting the INNER edge of the grid if the SUBgrid is outside of it. 

	  if( SUBlingGrid ){
	    Offset -= 2; 
	    Start[dim]++;
	    End[dim]++;
	    
	    //Also correct Dim, the size of the Initial Flux: it comes from This Grid, 
	    //not the Subgrid.
	    
	    for(i=0;i<GridRank;i++)
	      if(i != dim){
		Dim[i] = GridEndIndex[i]-GridStartIndex[i]+1;
		InitialOffset[i] = max( RefinedFluxes->LeftFluxStartGlobalIndex[dim][i]-
					InitialFluxes->LeftFluxStartGlobalIndex[dim][i],
					0);
	      }else{
		Dim[i] = 1;
		InitialOffset[i] = 0;
	      }
	  }
	  
	  
	  /* Check to see if we should correct BoundaryFluxesThisTimeStep
	     instead of the fields themselves. */
	  
	  CorrectLeftBoundaryFlux = FALSE;
	  CorrectRightBoundaryFlux = FALSE;
	  
	  if (Start[dim] == GridStartIndex[dim]-1){
	    CorrectLeftBoundaryFlux = TRUE;
	    CorrectLeftBaryonField  = FALSE;
	  }
	  if (Start[dim] + Offset == GridEndIndex[dim]+1){
	    CorrectRightBoundaryFlux = TRUE;
	    CorrectRightBaryonField  = TRUE;
	  }

	  /* Set GridFluxStartIndex to the starting position of the flux
	     plane (i.e. exclude grid boundary zones), except for the direction
	     of the flux is set such that GridStartIndex[dim] - Start[dim] = 0 */
	  
	  for (i = 0; i < MAX_DIMENSION; i++) {
	    GridFluxStartIndex[i] = GridStartIndex[i];
	    GridFluxDim[i] = GridEndIndex[i] - GridStartIndex[i] + 1;
	  }
	  
	  GridFluxStartIndex[dim] = Start[dim];
	  GridFluxDim[dim] = 1;
	  
	  /* Turn Offset (in dim direction) to Offset (in field array) */
	  
	  for (i = 0; i < dim; i++)
	    Offset *= GridDimension[i];
	  
	  /* Multiply faces by density to get conserved quantities 
	     (only multiply fields which we are going to correct) */
	  
	  if (HydroMethod != Zeus_Hydro)
	    for (field = 0; field < NumberOfBaryonFields; field++)
	      if (FieldTypeIsDensity(FieldType[field]) == FALSE &&
		  (RadiativeCooling == 0 || (FieldType[field] != TotalEnergy && 
					     FieldType[field] != InternalEnergy)))
		for (k = Start[2]; k <= End[2]; k++)
		  for (j = Start[1]; j <= End[1]; j++) {
		    index = (k*GridDimension[1] + j)*GridDimension[0] + Start[0];
		    for (i = Start[0]; i <= End[0]; i++, index++) {
		      BaryonField[field][index] *= BaryonField[DensNum][index];
		      BaryonField[field][index+Offset] *= 
			BaryonField[DensNum][index+Offset];
		    }
		  }
	  
	  /* Divide species by densities so that at the end we can multiply
	     them by the new density (species are not otherwise modified --
	     see the next comment).  This ensures that the species are changed
	     to keep the same fractional density. */
	  
	  for (field = 0; field < NumberOfBaryonFields; field++)
	    if (FieldType[field] >= ElectronDensity && 
		FieldType[field] < FieldUndefined)
	      for (k = Start[2]; k <= End[2]; k++)
		for (j = Start[1]; j <= End[1]; j++) {
		  index = (k*GridDimension[1] + j)*GridDimension[0] + Start[0];
		  for (i = Start[0]; i <= End[0]; i++, index++) {
		    BaryonField[field][index] /= BaryonField[DensNum][index];
		    BaryonField[field][index+Offset] /= 
		      BaryonField[DensNum][index+Offset];
		  }
		}
	  
	  /* Correct face for difference between refined and initial fluxes. 
	     (Don't do this for energy if radiative cooling is on because it's
	     no longer conserved.  Similarly, don't do it for the species
	     because they are not individually conserved either -- in fact,
	     this could be done for the conserved quantities like charge, 
	     total number density summed over ionization, etc.) */
	  
	  
	  for (field = 0; field < NumberOfBaryonFields; field++){
	    if ((RadiativeCooling == 0 || (FieldType[field] != TotalEnergy && 
					   FieldType[field] != InternalEnergy))
		&& (FieldType[field] < ElectronDensity)) {
	      for (k = Start[2]; k <= End[2]; k++){
		for (j = Start[1]; j <= End[1]; j++){
		  for (i = Start[0]; i <= End[0]; i++) {
		    
		    /* Compute indexes. */
		    
		    FieldIndex = (k*GridDimension[1] + j)*GridDimension[0] + i;
		    FluxIndex  = ((k - Start[2]+InitialOffset[2])*Dim[1] + 
				  (j - Start[1]+InitialOffset[1]))*Dim[0] +
		      (i - Start[0]+InitialOffset[0]);
		    
		    if( SUBlingGrid ){
		      RefinedFluxIndex = ((k - Start[2] + RefinedOffset[2])*RefinedDim[1] +
					  (j - Start[1] + RefinedOffset[1]))*RefinedDim[0] +
			(i - Start[0] + RefinedOffset[0]);
		      
		    }else{
		      RefinedFluxIndex = FluxIndex;
		    }
		    
		    GridFluxIndex = 
		      (i - GridFluxStartIndex[0]) 
		      + (j - GridFluxStartIndex[1])*GridFluxDim[0]
		      + (k - GridFluxStartIndex[2])*GridFluxDim[1]*GridFluxDim[0];
		    
		    
		    if (CorrectLeftBoundaryFlux)
		      BoundaryFluxesThisTimeStep->LeftFluxes[field][dim][GridFluxIndex] =
			RefinedFluxes->LeftFluxes[field][dim][FluxIndex];
		    
		    if(CorrectLeftBaryonField){
		      
		      if( SUBlingGrid == FALSE ){
			BaryonField[field][FieldIndex] +=
			  (InitialFluxes->LeftFluxes[field][dim][FluxIndex] -
			   RefinedFluxes->LeftFluxes[field][dim][FluxIndex] )/
			  (CellWidth[dim][0]*a);
			
		      }else{ /* if( SUBlingGrid == False) */
			
			BaryonField[field][FieldIndex] -= 
			  (InitialFluxes->LeftFluxes[field][dim][FluxIndex] -
			   RefinedFluxes->RightFluxes[field][dim][RefinedFluxIndex] )/
			  (CellWidth[dim][0]*a);
			
		      }
		    }
		    
		    if (CorrectRightBoundaryFlux)
		      BoundaryFluxesThisTimeStep->RightFluxes[field][dim] [GridFluxIndex] =
			RefinedFluxes->RightFluxes[field][dim][FluxIndex]; 
		    
		    /* update only if necessary */
		    if(CorrectRightBaryonField){
		      
		      if( SUBlingGrid == FALSE ){
			
			BaryonField[field][FieldIndex + Offset] -= 
			  (InitialFluxes->RightFluxes[field][dim][FluxIndex] -
			   RefinedFluxes->RightFluxes[field][dim][FluxIndex] )/
			  (CellWidth[dim][0]*a);
			
		      }else{ /* if( SUBlingGrid == FALSE ){ */
			BaryonField[field][FieldIndex + Offset] += 
			  (InitialFluxes->RightFluxes[field][dim][FluxIndex] -
			   RefinedFluxes->LeftFluxes[field][dim][RefinedFluxIndex] )/
			  (CellWidth[dim][0]*a);
			
		      } // else{ /* if( SUBlingGrid == FALSE ){ */
		    } // if(CorrectRightBaryonField)
		  
		    if ((FieldTypeIsDensity(FieldType[field]) == TRUE ||
			 FieldType[field] == TotalEnergy ||
			 FieldType[field] == InternalEnergy) &&
			(BaryonField[field][FieldIndex] <= 0 ||
			 BaryonField[field][FieldIndex+Offset] <= 0)) {
		      
		      fprintf(stderr,"ERROR: CorrectForRefinedFluxes causing problems.\n");
		      fprintf(stderr,"      Density or Energy is negative.\n");
		      fprintf(stderr,"      Please contact your Enzo service professional.\n");
		      return FAIL;
		    }
		  }// for (i = Start[0]; i <= End[0]; i++) {
		} // for (j = Start[1]; j <= End[1]; j++){
	      } // for (k = Start[2]; k <= End[2]; k++){  
	    }	// if ((RadiativeCooling == 0 || (FieldType[field] != TotalEnergy && etc 
	  } // for (field = 0; field < NumberOfBaryonFields; field++){
	  
	    /* Return faces to original quantity. */
	  
	  if (HydroMethod != Zeus_Hydro)
	    for (field = 0; field < NumberOfBaryonFields; field++)
	      if (FieldTypeIsDensity(FieldType[field]) == FALSE &&
		  (RadiativeCooling == 0 || (FieldType[field] != TotalEnergy && 
					     FieldType[field] != InternalEnergy)))
		for (k = Start[2]; k <= End[2]; k++)
		  for (j = Start[1]; j <= End[1]; j++) {
		    index = (k*GridDimension[1] + j)*GridDimension[0] + Start[0];
		    for (i = Start[0]; i <= End[0]; i++, index++) {
		      BaryonField[field][index] /= BaryonField[DensNum][index];
		      BaryonField[field][index+Offset] /=
			BaryonField[DensNum][index+Offset];
		    }
		  }
	  
	  /* If appropriate, restore consistency between total and internal
	     energy in corrected faces. */
	  
	  if (DualEnergyFormalism == TRUE && RadiativeCooling == FALSE){
	    for (k = Start[2]; k <= End[2]; k++)
	      for (j = Start[1]; j <= End[1]; j++) {
		i1 = (k*GridDimension[1] + j)*GridDimension[0] + Start[0];
		i2 = i1 + Offset;
		for (i = Start[0]; i <= End[0]; i++, i1++, i2++) {
		  BaryonField[GENum][i1] = max(BaryonField[GENum][i1], 
					       tiny_number);
		  BaryonField[GENum][i2] = max(BaryonField[GENum][i2],
					       tiny_number);
		  BaryonField[TENum][i1] = BaryonField[GENum][i1] +
		    0.5 * BaryonField[Vel1Num][i1] * BaryonField[Vel1Num][i1];
		  BaryonField[TENum][i2] = BaryonField[GENum][i2] + 
		    0.5 * BaryonField[Vel1Num][i2] * BaryonField[Vel1Num][i2];
		  if (GridRank > 1) {
		    BaryonField[TENum][i1] += 
		      0.5 * BaryonField[Vel2Num][i1] * BaryonField[Vel2Num][i1];
		    BaryonField[TENum][i2] += 
		      0.5 * BaryonField[Vel2Num][i2] * BaryonField[Vel2Num][i2];
		  }
		  if (GridRank > 2) {
		    BaryonField[TENum][i1] += 
		      0.5 * BaryonField[Vel3Num][i1] * BaryonField[Vel3Num][i1];
		    BaryonField[TENum][i2] += 
		      0.5 * BaryonField[Vel3Num][i2] * BaryonField[Vel3Num][i2];
		  }
		  
		}		    
	      } // end: loop over faces
	  } // end: if (DualEnergyFormalism)
	  
	    /* Multiply species by density to return from fractional to real
	       density. (see comments above regarding species). */
	  
	  for (field = 0; field < NumberOfBaryonFields; field++)
	    if (FieldType[field] >= ElectronDensity && 
		FieldType[field] < FieldUndefined)
	      for (k = Start[2]; k <= End[2]; k++)
		for (j = Start[1]; j <= End[1]; j++) {
		  index = (k*GridDimension[1] + j)*GridDimension[0] + Start[0];
		  for (i = Start[0]; i <= End[0]; i++, index++) {
		    BaryonField[field][index] *= BaryonField[DensNum][index];
		    BaryonField[field][index+Offset] *=
		      BaryonField[DensNum][index+Offset];
		  }
		}
	  
	} // if( CorrectLeftBaryonField || CorrectRightBaryonField){ 
      } // end: if GridDimension[dim] > 1
      /* delete Refined fluxes as they're not needed anymore. */
      
      for (field = 0; field < NumberOfBaryonFields; field++) {
	delete RefinedFluxes->LeftFluxes[field][dim];
	delete RefinedFluxes->RightFluxes[field][dim];
	RefinedFluxes->LeftFluxes[field][dim] = NULL;
	RefinedFluxes->RightFluxes[field][dim] = NULL;
      }
      
    } // next dimension
  } // Number of baryons fields > 0 
  
  return SUCCESS;
  
}
  
