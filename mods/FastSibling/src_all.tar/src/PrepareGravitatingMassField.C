/***********************************************************************
/
/  PREPARE THE GRAVITATING MASS FIELD
/
/  written by: Greg Bryan
/  date:       January, 1998
/  modified1:
/
/  PURPOSE:
/
************************************************************************/

#include <stdio.h>
#ifdef USE_MPI
#include "mpi.h"
#endif /* USE_MPI */
#include "macros_and_parameters.h"
#include "typedefs.h"
#include "global_data.h"
#include "Fluxes.h"
#include "GridList.h"
#include "ExternalBoundary.h"
#include "Grid.h"
#include "Hierarchy.h"
#include "LevelHierarchy.h"
#include "TopGridData.h"
#include "communication.h"

/* function prototypes */

int DepositBaryons(HierarchyEntry *Grid);

/* EvolveHierarchy function */

int PrepareGravitatingMassField1(HierarchyEntry *Grid)
{

  /* declarations */

  int RefinementFactor = RefineBy;
  grid *CurrentGrid = Grid->GridData;

  /* Gravity: initialize and clear the gravitating mass field. */

  if (CommunicationDirection == COMMUNICATION_POST_RECEIVE ||
      CommunicationDirection == COMMUNICATION_SEND_RECEIVE) {
    if (CurrentGrid->InitializeGravitatingMassField(RefinementFactor) == FAIL){
      fprintf(stderr, "Error in grid->InitializeGravitatingMassField.\n");
      return FAIL;
    }
    CurrentGrid->ClearGravitatingMassField();
  }

  /* Baryons: copy parent density (no interpolation) to regions in
     GravitatingMassField which are beyond the boundary of the current grid. */

  int CommunicationReceiveIndexLast = CommunicationReceiveIndex;
  CommunicationReceiveCurrentDependsOn = COMMUNICATION_NO_DEPENDENCE;
  if (Grid->ParentGrid != NULL)
   if (CurrentGrid->CopyParentToGravitatingFieldBoundary(
				         Grid->ParentGrid->GridData) == FAIL) {
     fprintf(stderr, "Error in grid->CopyParentToGravitatingFieldBoundary.\n");
     return FAIL;
   }
  //  if (CommunicationReceiveIndex != CommunicationReceiveIndexLast)
  //    CommunicationReceiveCurrentDependsOn = CommunicationReceiveIndex-1;

  return SUCCESS;
}



int PrepareGravitatingMassField2(HierarchyEntry *Grid, int grid1, 
				 SiblingGridList SiblingList[],
				 TopGridData *MetaData, int level)
{

  /* declarations */

  int grid2;
  grid *CurrentGrid = Grid->GridData;
  
  /* Baryons: deposit mass into GravitatingMassField. */

  //  CurrentGrid->AddBaryonsToGravitatingMassField(); /* cheap way */

  if (DepositBaryons(Grid) == FAIL) {
    fprintf(stderr, "Error in grid->AddBaryonsToGravitatingMassField\n");
    return FAIL;
  }

  /* Particles: go through all the other grids on this level and add all 
     their overlapping GravitatingMassFieldParticles to this grid's
     GravitatingMassField.  Handle periodicity properly. */

  for (grid2 = 0; grid2 < SiblingList[grid1].NumberOfSiblings; grid2++)
    if (CurrentGrid->CheckForOverlap(SiblingList[grid1].GridList[grid2],
				     MetaData->LeftFaceBoundaryCondition,
				     MetaData->RightFaceBoundaryCondition,
				     &grid::AddOverlappingParticleMassField)
	== FAIL) {
      fprintf(stderr, "Error in grid->AddOverlappingParticleMassFields.\n");
    }

#ifdef UNUSED
  FLOAT Zero[] = {0,0,0};
  if (CurrentGrid->AddOverlappingParticleMassField(CurrentGrid,Zero) == FAIL) {
    fprintf(stderr, "Error in grid->AddOverlappingParticleMassField.\n");
    return FAIL;
  }
#endif /* UNUSED */

  /* Particles: deposit particles in the parent grid into GravitatingMassField
     (they should only be in the boundaries).  We should really do this for
     all parent grids.  Or better yet do a PP summation. sigh. */

#ifdef UNUSED
  if (Grid->ParentGrid != NULL) {

/* The following is done to allow this to be parallelized. */
//    FLOAT TimeMidStep = CurrentGrid->ReturnTime() + 
//                        0.5*CurrentGrid->ReturnTimeStep();
      FLOAT TimeMidStep = Grid->ParentGrid->GridData->ReturnTime();

    if (Grid->ParentGrid->GridData->DepositParticlePositions(CurrentGrid,
			       TimeMidStep, GRAVITATING_MASS_FIELD) == FAIL) {
      fprintf(stderr, "Error in grid->DepositParticlePositions.\n");
      return FAIL;
    }
  }
#endif /* UNUSED */

  /* If we are using comoving coordinates, we must adjust the source term. */

  if (CommunicationDirection == COMMUNICATION_SEND ||
      CommunicationDirection == COMMUNICATION_SEND_RECEIVE) {

    if (ComovingCoordinates)
      if (CurrentGrid->ComovingGravitySourceTerm() == FAIL) {
	fprintf(stderr, "Error in grid->ComovingGravitySourceTerm.\n");
	return FAIL;
      }

  } // end: if (CommunicationDirection != COMMUNICATION_SEND)

  /* Make a guess at the potential for this grid. */

  CommunicationReceiveCurrentDependsOn = COMMUNICATION_NO_DEPENDENCE;
  if (level > 0)
    if (CurrentGrid->PreparePotentialField(Grid->ParentGrid->GridData) 
	== FAIL) {
      fprintf(stderr, "Error in grid->PreparePotential.\n");
      return FAIL;
    }

  return SUCCESS;
}
