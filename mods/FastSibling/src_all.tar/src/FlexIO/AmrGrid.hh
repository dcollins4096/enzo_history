#ifndef __AMR_GRID_HH_
#define __AMR_GRID_HH_
/*
  Definition of the AMR grid structure for C
*/

struct AmrGrid : public AmrGridT {
  IObase::DataType datatype;
};

#endif
