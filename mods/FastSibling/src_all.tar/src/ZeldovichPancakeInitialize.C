/***********************************************************************
/
/  INITIALIZE A ZELDOVICH PANCAKE
/
/  written by: Greg Bryan
/  date:       April, 1995
/  modified1:
/
/  PURPOSE:
/
/  RETURNS: SUCCESS or FAIL
/
************************************************************************/

// This routine intializes a new simulation based on the parameter file.
//

#include <string.h>
#include <stdio.h>
#include "macros_and_parameters.h"
#include "typedefs.h"
#include "global_data.h"
#include "Fluxes.h"
#include "GridList.h"
#include "ExternalBoundary.h"
#include "Grid.h"
#include "Hierarchy.h"
#include "TopGridData.h"
#include "CosmologyParameters.h"

int ZeldovichPancakeInitialize(FILE *fptr, FILE *Outfptr, 
			       HierarchyEntry &TopGrid)
{
  char *DensName = "Density";
  char *TEName   = "Total Energy";
  char *GEName   = "Gas Energy";
  char *Vel1Name = "x-velocity";
  char *Vel2Name = "y-velocity";
  char *Vel3Name = "z-velocity";

  /* declarations */

  char line[MAX_LINE_LENGTH];
  int ret;

  /* Error check. */

  if (!ComovingCoordinates) {
    fprintf(stderr, "ComovingCoordinates must be TRUE!\n");
    return FAIL;
  }

  if (!SelfGravity)
    fprintf(stderr, "ZeldovichPancake: gravity is off!?!\n");
  if (CellFlaggingMethod[0] < 2)
    fprintf(stderr, "ZeldovichPancake: check CellFlaggingMethod.\n");

  /* set default parameters */

  int   ZeldovichPancakeDirection          = 0;    // along the x-axis
  float ZeldovichPancakeCentralOffset      = 0.0;  // no offset
  float ZeldovichPancakeOmegaBaryonNow     = 1.0;  // standard
  float ZeldovichPancakeOmegaCDMNow        = 0.0;  // no dark matter
  float ZeldovichPancakeCollapseRedshift   = 1.0;  // free parameter
  float ZeldovichPancakeInitialTemperature = 100;  // whatever

  /* read input from file */

  while (fgets(line, MAX_LINE_LENGTH, fptr) != NULL) {

    ret = 0;

    /* read parameters */

    ret += sscanf(line, "ZeldovichPancakeDirection = %d", 
		  &ZeldovichPancakeDirection);
    ret += sscanf(line, "ZeldovichPancakeCentralOffset = %f", 
		  &ZeldovichPancakeCentralOffset);
    ret += sscanf(line, "ZeldovichPancakeOmegaBaryonNow = %f", 
		  &ZeldovichPancakeOmegaBaryonNow);
    ret += sscanf(line, "ZeldovichPancakeOmegaCDMNow = %f", 
		  &ZeldovichPancakeOmegaCDMNow);
    ret += sscanf(line, "ZeldovichPancakeCollapseRedshift = %f", 
		  &ZeldovichPancakeCollapseRedshift);
    ret += sscanf(line, "ZeldovichPancakeInitialTemperature = %f", 
		  &ZeldovichPancakeInitialTemperature);

    /* if the line is suspicious, issue a warning */

    if (ret == 0 && strstr(line, "=") && strstr(line, "ZeldovichPancake"))
      fprintf(stderr, "warning: the following parameter line was not interpreted:\n%s\n", line);

  }

  /* set up grid */

  if (TopGrid.GridData->ZeldovichPancakeInitializeGrid(
					  ZeldovichPancakeDirection,
					  ZeldovichPancakeCentralOffset,
					  ZeldovichPancakeOmegaBaryonNow,
					  ZeldovichPancakeOmegaCDMNow,
					  ZeldovichPancakeCollapseRedshift,
					  ZeldovichPancakeInitialTemperature
						       ) == FAIL) {
    fprintf(stderr, "Error in ZeldovichPancakeInitializeGrid.\n");
    return FAIL;
  }

  /* set up field names and units */

  int i = 0;
  DataLabel[i++] = DensName;
  DataLabel[i++] = TEName;
  if (DualEnergyFormalism)
    DataLabel[i++] = GEName;
  DataLabel[i++] = Vel1Name;
  DataLabel[i++] = Vel2Name;
  DataLabel[i++] = Vel3Name;

  DataUnits[0] = NULL;
  DataUnits[1] = NULL;
  DataUnits[2] = NULL;
  DataUnits[3] = NULL;
  DataUnits[4] = NULL;

  /* Write parameters to parameter output file */

  if (MyProcessorNumber == ROOT_PROCESSOR) {
    fprintf(Outfptr, "ZeldovichPancakeDirection          = %d\n",
	    ZeldovichPancakeDirection);
    fprintf(Outfptr, "ZeldovichPancakeCentralOffset      = %f\n", 
	    ZeldovichPancakeCentralOffset);
    fprintf(Outfptr, "ZeldovichPancakeOmegaBaryonNow     = %f\n", 
	    ZeldovichPancakeOmegaBaryonNow);
    fprintf(Outfptr, "ZeldovichPancakeOmegaCDMNow        = %f\n", 
	    ZeldovichPancakeOmegaCDMNow);
    fprintf(Outfptr, "ZeldovichPancakeCollapseRedshift   = %f\n", 
	    ZeldovichPancakeCollapseRedshift);
    fprintf(Outfptr, "ZeldovichPancakeInitialTemperature = %f\n\n", 
	    ZeldovichPancakeInitialTemperature);
  }

  return SUCCESS;
}
