#include<stdio.h>
#include<stdlib.h>

#ifdef USE_MPI
#include <mpi.h>
#endif

void c_error (char *sourcefile, int linenumber)
{
#ifdef USE_MPI
  int  ierr;
#endif
  int error_code;
  int id;

#ifdef USE_MPI
  ierr = MPI_Comm_rank( MPI_COMM_WORLD, &id);
#else
  id = 0;
#endif

  printf ("==================\n");
  printf ("=== ENZO ERROR ===   %s: %d   node %d\n", 
	  sourcefile,linenumber,id);
  printf ("==================\n");
  fflush(stdout);
  
  error_code = -1;
#ifdef USE_MPI
  ierr = MPI_Abort( MPI_COMM_WORLD, error_code);
#else
  exit(error_code);
#endif
}

void c_warning (char *sourcefile, int linenumber)
{
#ifdef USE_MPI
  int  ierr;
#endif
  int id;

#ifdef USE_MPI
  ierr = MPI_Comm_rank( MPI_COMM_WORLD, &id);
#else
  id = 0;
#endif

  printf ("--- ENZO WARNING ---   %s: %d   node %d\n", 
	  sourcefile,linenumber,id);
  fflush(stdout);

}
