/***********************************************************************
/
/  GRID CLASS (INTERPOLATE PARTICLE AND GRID ACCELERATIONS)
/
/  written by: Greg Bryan
/  date:       January, 1999
/  modified1:
/
/  PURPOSE:
/
************************************************************************/

#include <stdio.h>
#include "macros_and_parameters.h"
#include "typedefs.h"
#include "global_data.h"
#include "Fluxes.h"
#include "GridList.h"
#include "ExternalBoundary.h"
#include "Grid.h"
#include "Hierarchy.h"
#include "LevelHierarchy.h"
#include "TopGridData.h"

/* function prototypes */

extern "C" void FORTRAN_NAME(int_grid_cic)(float *source,
				   float *dest, int *ndim, 
				   int *sdim1, int *sdim2, int *sdim3,
				   int *ddim1, int *ddim2, int *ddim3, 
				   float *start1, float *start2, float *start3,
				   int *refine1, int *refine2, int *refine3);


/* EvolveHierarchy function */

int grid::InterpolateAccelerations(grid *FromGrid)
{

  /* Return if this grid is not on this processor. */

  if (MyProcessorNumber != ProcessorNumber &&
      MyProcessorNumber != FromGrid->ProcessorNumber)
    return SUCCESS;

  if (CommunicationDirection == COMMUNICATION_SEND &&
      (MyProcessorNumber != FromGrid->ProcessorNumber || 
       ProcessorNumber == FromGrid->ProcessorNumber))
    return SUCCESS;

  if (CommunicationDirection == COMMUNICATION_RECEIVE &&
      MyProcessorNumber == FromGrid->ProcessorNumber &&
      ProcessorNumber != FromGrid->ProcessorNumber)
    return SUCCESS;
      
  /* Declarations. */

  float GridOffset[MAX_DIMENSION];
  int GridStart[MAX_DIMENSION], GridEnd[MAX_DIMENSION], GridDim[MAX_DIMENSION],
      GridActiveDim[MAX_DIMENSION], Refinement[MAX_DIMENSION], dim, size = 1;

  /* Compute refinement factors. */

  FromGrid->ComputeRefinementFactors(this, Refinement);

  /* Set unused dims to zero. */

  for (dim = GridRank; dim < MAX_DIMENSION; dim++) {
    GridOffset[dim] = 0;
    GridStart[dim] = GridEnd[dim] = 0;
    GridDim[dim] = GridActiveDim[dim] = 1;
  }

  /* Compute the GridOffset (in grid units) and GridStartIndex and
     the region dim (in grid units). */

  for (dim = 0; dim < GridRank; dim++) {
    GridOffset[dim] = (CellLeftEdge[dim][0] -
		       FromGrid->CellLeftEdge[dim][0])/
		       CellWidth[dim][0];
    GridDim[dim]    = GridDimension[dim];
#ifdef UNUSED
    GridStart[dim]  = nint(GridOffset[dim]/Refinement[dim]) - 1;
    GridEnd[dim]    = nint((GridStart[dim] + GridDim[dim])/Refinement[dim])+2;
#endif /* UNUSED */
    GridStart[dim]  = 0;
    GridEnd[dim]    = FromGrid->GridDimension[dim] - 1;
    GridActiveDim[dim] = GridEnd[dim] - GridStart[dim] + 1;
    size *= GridDimension[dim];

    if (GridOffset[dim] < 0) {
      fprintf(stderr, "GridOffset[%d] = %g < 0.\n", dim, GridOffset[dim]);
      return FAIL;
    }
  }

  /* Copy data from other processor if needed (modify GridDim and
     GridStartIndex to reflect the fact that we are only coping part of
     the grid. */

  if (ProcessorNumber != FromGrid->ProcessorNumber) {
    FromGrid->CommunicationSendRegion(FromGrid, ProcessorNumber, 
	    ACCELERATION_FIELDS, NEW_ONLY, GridStart, GridActiveDim);
#ifdef UNUSED
    for (dim = 0; dim < GridRank; dim++) {
      GridOffset[dim] = (CellLeftEdge[dim][GridStart[dim]] -
		       FromGrid->GravitatingMassFieldLeftEdge[dim])/
		       CellWidth[dim][0];
      GridDim[dim] = GridEnd[dim] - GridStart[dim] + 1;
      GridStart[dim] = 0;
      GridEnd[dim] = GridDim[dim] - 1;
    }
#endif /* UNUSED */
  }

  /* Return if this is not our concern. */

  if (MyProcessorNumber != ProcessorNumber)
    return SUCCESS;

  if (FromGrid->AccelerationField[0] == NULL) {
    fprintf(stderr, "FromGrid->AccelerationField is NULL.\n");
    return FAIL;
  }

  /* Allocate acceleration fields. */

  for (dim = 0; dim < GridRank; dim++) {
    delete [] AccelerationField[dim];
    AccelerationField[dim] = new float[size];
  }

  /* --------------------------------------------------- */
  /* Interpolate accelerations to particles.             */

  if (NumberOfParticles > 0) {

    /* Clear particle accelerations. */

    this->ClearParticleAccelerations();

    /* Move particles 1/2 step forward in preparation for interpolation. */

    this->UpdateParticlePosition(0.5*dtFixed);

    /* Interpolate the accelerations back to the grid and particles. 
       (this assumes that FromGrid's acdeleration fields have been copied
        from the other processor in their entirety).  Also, note hack
       to prevent error. */

    int hold = FromGrid->ProcessorNumber;
    FromGrid->ProcessorNumber = ProcessorNumber;
    this->InterpolateParticlePositions(FromGrid, 
	     (HydroMethod == Zeus_Hydro) ? ZEUS_GRIDS : GRIDS);
    FromGrid->ProcessorNumber = hold;

    /* Move particles 1/2 step backwards to return to original positions. */

    this->UpdateParticlePosition(-0.5*dtFixed);

  } // end: if (NumberOfParticles > 0)

  /* --------------------------------------------------- */
  /* Interpolate acceleration field for cells. */

  if (NumberOfBaryonFields > 0)
    for (dim = 0; dim < GridRank; dim++) {

      /* If using zeus, then shift the offset since accelerations are
	 face centered. */

      if (HydroMethod == Zeus_Hydro)
	GridOffset[dim] += 0.5*(FromGrid->CellWidth[dim][0] - 
				CellWidth[dim][0])/CellWidth[dim][0];

      /* Call a fortran routine to do the work. */

      FORTRAN_NAME(int_grid_cic)(FromGrid->AccelerationField[dim],
				 AccelerationField[dim], &GridRank,
				 FromGrid->GridDimension,
				 FromGrid->GridDimension+1,
				 FromGrid->GridDimension+2,
				 GridDimension, GridDimension+1,
				     GridDimension+2,
				 GridOffset, GridOffset+1, GridOffset+2,
				 Refinement, Refinement+1, Refinement+2);

      /* Shift back, if necessary. */

      if (HydroMethod == Zeus_Hydro)
	GridOffset[dim] -= 0.5*(FromGrid->CellWidth[dim][0] - 
				CellWidth[dim][0])/CellWidth[dim][0];

    }

  return SUCCESS;
}
