/***********************************************************************
/
/  READ HDF5 DATASET ATTRIBUTE
/
/  written by: Robert Harkness
/  date:       July 2002
/  modified1:
/
/  PURPOSE:
/
/  RETURNS: SUCCESS or FAILS HARD
/
************************************************************************/

#ifdef USE_HDF5

#include <hdf5.h>
#include <stdio.h>
#include <assert.h>

#include "macros_and_parameters.h"

// HDF5 function prototypes

#include "extern_hdf5.h"

int ReadAttrHDF5(char *Fname, int *Rank, int Dims[], int *NSeg, int *LSeg, FILE *log_fptr)
{

  hid_t       file_id, dset_id, attr_id;
  herr_t      h5_status;
  herr_t      h5_error = -1;

  int         component_rank_attr;
  int         component_size_attr;
  int         field_rank_attr;
  int         field_dims_attr[3];

  int         dim;

#ifdef IO_LOG
  int         io_log = 1;
#else
  int         io_log = 0;
#endif

  if (io_log) fprintf(log_fptr, "H5Fopen with Name = %s\n", Fname);

  file_id = H5Fopen(Fname, H5F_ACC_RDONLY, H5P_DEFAULT);
    if (io_log) fprintf(log_fptr, "H5Fopen id: %d\n", file_id);
    assert( file_id != h5_error );

  if (io_log) fprintf(log_fptr, "H5Dopen with Name = %s\n", Fname);

  dset_id =  H5Dopen(file_id, Fname);
    if (io_log) fprintf(log_fptr, "H5Dopen id: %d\n", dset_id);
    assert( dset_id != h5_error );


  if (io_log) fprintf(log_fptr, "H5Aopen_name with Name = Component_Rank\n");

  attr_id = H5Aopen_name(dset_id, "Component_Rank");
    if (io_log) fprintf(log_fptr, "H5Aopen_name id: %d\n", attr_id);
    assert( attr_id != h5_error );

  h5_status = H5Aread(attr_id, HDF5_I4, &component_rank_attr);
    if (io_log) fprintf(log_fptr, "H5Aread: %d\n", h5_status);
    assert( h5_status != h5_error );

  h5_status = H5Aclose(attr_id);
    if (io_log) fprintf(log_fptr, "H5Aclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  if (io_log) fprintf(log_fptr, "COMPONENT RANK %d\n", component_rank_attr);


  if (io_log) fprintf(log_fptr, "H5Aopen_name with Name = Component_Size\n");

  attr_id = H5Aopen_name(dset_id, "Component_Size");
    if (io_log) fprintf(log_fptr, "H5Aopen_name id: %d\n", attr_id);
    assert( attr_id != h5_error );

  h5_status = H5Aread(attr_id, HDF5_I4, &component_size_attr);
    if (io_log) fprintf(log_fptr, "H5Aread: %d\n", h5_status);
    assert( h5_status != h5_error );

  h5_status = H5Aclose(attr_id);
    if (io_log) fprintf(log_fptr, "H5Aclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  if (io_log) fprintf(log_fptr, "COMPONENT SIZE %d\n", component_size_attr);


  if (io_log) fprintf(log_fptr, "H5Aopen_name with Name = Rank\n");

  attr_id = H5Aopen_name(dset_id, "Rank");
    if (io_log) fprintf(log_fptr, "H5Aopen_name id: %d\n", attr_id);
    assert( attr_id != h5_error );

  h5_status = H5Aread(attr_id, HDF5_I4, &field_rank_attr);
    if (io_log) fprintf(log_fptr, "H5Aread: %d\n", h5_status);
    assert( h5_status != h5_error );

  h5_status = H5Aclose(attr_id);
    if (io_log) fprintf(log_fptr, "H5Aclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  if (io_log) fprintf(log_fptr, "RANK %d\n", field_rank_attr);


  if (io_log) fprintf(log_fptr, "H5Aopen_name with Name = Dimensions\n");

  attr_id = H5Aopen_name(dset_id, "Dimensions");
    if (io_log) fprintf(log_fptr, "H5Aopen_name id: %d\n", attr_id);
    assert( attr_id != h5_error );

  h5_status = H5Aread(attr_id, HDF5_I4, field_dims_attr);
    if (io_log) fprintf(log_fptr, "H5Aread: %d\n", h5_status);
    assert( h5_status != h5_error );

  h5_status = H5Aclose(attr_id);
    if (io_log) fprintf(log_fptr, "H5Aclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  for ( dim=0; dim < field_rank_attr; dim++ )
  {
    if (io_log) fprintf(log_fptr, "DIMS %d:  %d\n", dim, field_dims_attr[dim]);
  }


  h5_status = H5Dclose(dset_id);
    if (io_log) fprintf(log_fptr, "H5Dclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  h5_status = H5Fclose(file_id);
    if (io_log) fprintf(log_fptr, "H5Fclose: %d\n", h5_status);
    assert( h5_status != h5_error );

  *Rank = field_rank_attr;
  *NSeg = component_rank_attr;
  *LSeg = component_size_attr;

  for(dim = 0; dim < field_rank_attr; dim++)
  {
    Dims[dim] = field_dims_attr[dim];
  }

  return SUCCESS;

}
#endif /* USE_HDF5 */
