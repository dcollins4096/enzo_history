      REAL*8 f77rand
      EXTERNAL f77rand


